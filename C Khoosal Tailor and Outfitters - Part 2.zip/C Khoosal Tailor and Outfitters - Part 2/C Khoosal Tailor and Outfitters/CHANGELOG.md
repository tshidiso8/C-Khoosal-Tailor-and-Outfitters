# Changelog

All notable changes to the C Khoosal Tailor and Outfitters website are documented below.


### Added
- Added a dedicated enquiries page to improve customer communication.
- Added direct contact details and enquiry form structure for customer support.
- Linked the enquiries page in the main navigation across all website pages.

## [Part 2] - 2026-09-18

### Added
- Created a full external stylesheet in `style.css` for consistent branding across the site.
- Added responsive layout styling for desktop, tablet, and mobile views.
- Added design tokens for colours, spacing, borders, and typography consistency.
- Added a dedicated `enquiries.html` page with a contact form and contact details.
- Added form styling for registration and enquiry fields.
- Added a homepage contact section with call and email links.
- Added responsive image handling and lazy loading for below-the-fold media.

### Changed
- Updated the navigation bar to include the Enquiries page.
- Improved typography using Google Fonts (`Archivo` and `Inter`).
- Standardised layout spacing, card styles, buttons, and link hover states.
- Refined product, brand, and payment sections for a cleaner shopping experience.

### Fixed
- Improved accessibility by adding descriptive `alt` text to images.
- Standardised form labels and field associations for accessibility.
- Corrected inconsistent page structure and heading flow.
- Ensured consistent navigation structure across all pages.

## [Part 1] - Initial Website Build

### Added
- Created the initial multi-page website structure:
  - `index.html`
  - `lists.html`
  - `table.html`
  - `registration.html`
- Added product listings for Dickies, Lacoste, Converse, Carvela, Bishop, and NAVADA.
- Added store information and map section for the About page.
- Added registration form for customer sign-up.
- Added payment method section to the product catalogue pages.

### Changed
- Added initial website content, product names, prices, and sizes.
- Organised the site into a clear multi-page layout for the business.

### Fixed
- Initial issues were reviewed and corrected during the Part 2 redesign and styling phase.

---

© 2026, C Khoosal Tailor and Outfitters
